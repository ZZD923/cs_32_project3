#ifndef ACTOR_H_
#define ACTOR_H_
#include "GraphObject.h"
#include "GameConstants.h"
class StudentWorld;
class actor:public GraphObject{
public:
    actor(int imageID, int startX, int startY, Direction dir, double size , unsigned int depth ,StudentWorld *ap)
    :GraphObject(imageID,startX,startY,dir,size,depth){
                m_dead=false;
        m_hitpoint=0;
        m_world=ap;
    }
    virtual ~actor();
        void setdead(){
        m_dead=true;
    }
    StudentWorld*returnworld(){
        return m_world;
    }

    bool deadstaus(){
    
        return m_dead;
    }
    void sethitpoint(int initial){
        m_hitpoint=initial;
    
    }
    double gethitpoint(){
        return m_hitpoint;
    }
    virtual void dosomething()=0;
    virtual void getannoyed()=0;
private:
    bool m_dead;
    double m_hitpoint;
    StudentWorld *m_world;
    };

class Dirt:public actor{
public:
    Dirt(int startX,StudentWorld* ap,int startY)
    :actor(IID_DIRT,startX,startY,right,0.25,3.0,ap )
    {  
        setVisible(true);}
    virtual~Dirt(){}
    virtual void dosomething(){
    }
    virtual void getannoyed(){

    }
private:

};
class Frackman:public actor{
public:
    Frackman(StudentWorld *world);
    int getsonar(){
        return m_sonar;
    }
    void decsonar(){
        m_sonar--;
    }
    int getgold()
    {return m_gold;}
    int getsquirt(){
        return m_squirt;
    }
    
    virtual ~Frackman(){}
    
    virtual void dosomething();
    virtual void getannoyed(){
        return;
    }
private:
    int m_sonar;
    int m_gold;
    int m_squirt;
};
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

#endif // ACTOR_H_
