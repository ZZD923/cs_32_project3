#include "Actor.h"
#include "StudentWorld.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
    return new StudentWorld(assetDir);
}
void StudentWorld::setDisplayText(){
    int score=getScore();
    string scr;
    if (score<10) {
        scr="00000"+to_string(score);
    }
    if (score>=10&&score<100) {
        scr="0000"+to_string(score);
    }
    if (score>=100&&score<1000) {
        scr="000"+to_string(score);
    }
    if (score>=1000&&score<10000) {
        scr="00"+to_string(score);
    }
    if (score>=10000&&score<100000) {
        scr="0"+to_string(score);
    }
    if (score>=100000) {
        scr=to_string(score);
    }
    int level=getLevel();
    string lvl;
    if (level<10) {
        lvl=" "+to_string(level);
    }
    if (level>=10) {
        lvl=to_string(level);
    }
    int health=m_frackman->gethitpoint()*10;
    string heal;
    if (health==100) {
        heal=to_string(health)+"%";
    }
    else{
    heal=" "+to_string(health)+"%";
    }
    int lives=getLives();
    string live=to_string(lives);
    int squirts = m_frackman->getsquirt();
    string squirt;
    if (squirts<10) {
        squirt=" "+to_string(squirts);
    }
    else{
        squirt=to_string(squirts);
    }
    int gold = m_frackman->getgold();
    string gld;
    if (gold<10) {
        gld=" "+to_string(gold);
    }
    else{
        gld=to_string(gold);
    }
    int sonar =m_frackman->getsonar();
    string son;
    if (sonar<10) {
        son=" "+to_string(sonar);
    }
    else{
        son=to_string(sonar);
    }

    int barrelsLeft = 3;
    string barrel;
    if (barrelsLeft<10) {
        barrel=" "+to_string(barrelsLeft);
    }
    else{
        barrel=to_string(barrelsLeft);
    }
    

    string s="Scr: "+scr+"  Lvl: "+lvl+"  Lives: "+live+"  Hlth: "+heal+"  Wtr: "+squirt+"  Gld: "+gld+"  Sonar: "+son+"  Oil Left: "+barrel;
    setGameStatText(s);
    
    //"Scr: 0321000 Lvl: 52 Lives: 3 Hlth: 80% Water: 20 Gld: 3 Sonar: 1 Oil Left: 2”
}
int StudentWorld::init()
{   m_frackman=new Frackman(this);
    for(int i=0;i<64;i++){
        for(int j=0;j<60;j++){
            if (i>=30&&i<=33&&j>=4&&j<=59) {
               m_dirt[i][j]=nullptr;
            }
            else{
                m_dirt[i][j]=new Dirt(i,this,j);}
        }
    }
    return GWSTATUS_CONTINUE_GAME;
}
// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp
