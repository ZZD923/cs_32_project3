#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <string>
#include<vector>
using namespace std;
class Actor;
class Dirt;
class Frackman;
// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
	 : GameWorld(assetDir)
    {delete m_frackman;
        
        for(int i=0;i<64;i++){
            for(int j=0;j<60;j++){
                delete m_dirt[i][j];
            }
        }

       
	}
    void setDisplayText();
    virtual~StudentWorld(){
        
        cout<<"fuck";
    }
    virtual int init();
   	virtual int move()
	{
		  // This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
		  // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
        if (m_frackman->deadstaus()==true) {
            decLives();
            return GWSTATUS_PLAYER_DIED;

        }
        else {
            setDisplayText();
            m_frackman->dosomething();
            
            return GWSTATUS_CONTINUE_GAME;
        }
        
    }
    
	virtual void cleanUp()
    {
        delete m_frackman;
        
        for(int i=0;i<64;i++){
            for(int j=0;j<60;j++){
                delete m_dirt[i][j];
            }
        }

        
    
    }
    void deletedirt(int x,int y){
        if(x>=64||y>=60||(x>=30&&x<=33&&y>=4&&y<=59))
            return;
        else if (m_dirt[x][y]->isVisible()==true) {
            playSound(SOUND_DIG);
            m_dirt[x][y]->setVisible(false);

                     }
        
        else{
            return;        }
    }
private:
    Frackman *m_frackman;
    Dirt  *m_dirt[64][60];
};

#endif // STUDENTWORLD_H_
