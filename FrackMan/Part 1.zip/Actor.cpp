#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp
actor::~actor(){
}

Frackman::Frackman(StudentWorld *world): actor(IID_PLAYER,30,60,right,1,0.0,world)
{     sethitpoint(10);
    setVisible(true);
    m_sonar=1;
    m_gold=0;
    m_squirt=5;}

 void Frackman:: dosomething(){
    if (deadstaus()==true) {
        return;
    }
    else{
        
    for (int i=getX(); i<=(getX()+3); i++) {
         for (int j=getY(); j<=(getY()+3); j++) {
             returnworld()->deletedirt(i,j);
         }
     }
     //remove dirt
         int ch;
     if (returnworld()->getKey(ch) == true) {
         // user hit a key this tick! switch (ch)
         switch (ch){
             case  KEY_PRESS_LEFT:
                 if (getDirection()!=left) {
                     setDirection(left);
                 }
                 if(getX()>0)
                     moveTo(getX()-1, getY());
                     break;
             case  KEY_PRESS_RIGHT:
                 if (getDirection()!=right) {
                     setDirection(right);
                 }

                 if(getX()<60)
                     moveTo(getX()+1, getY());
                 break;
             case KEY_PRESS_UP:
                 if (getDirection()!=up) {
                     setDirection(up);
                 }

                 if (getY()<60) {
                     moveTo(getX(), getY()+1);
                 }
                 break;
             case KEY_PRESS_DOWN:
                 if (getDirection()!=down) {
                     setDirection(down);
                 }

                 if (getY()>0) {
                     moveTo(getX(), getY()-1);
                 }
                 break;
             case KEY_PRESS_ESCAPE:
                 setdead();
                 break;
                 default:
                 break;
         
         }
     }
   //remove dirt

    return;
    }
}